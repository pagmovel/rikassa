<h2>Obrigado por confirmar seu e-mail</h2>
<p>Agora so faltar realizar o pagamento</p>
<br>
<p>Escolha com deseja realizar seu pagamento</p>
<br><br><br>

<a href="">Pix</a>
<br>
<br>
<a href="{{ $link_pagamento }}">Cartão de crédito</a>
