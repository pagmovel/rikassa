<?php

namespace App\Services;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use MercadoPago\Client\Preference\PreferenceClient;
use MercadoPago\MercadoPagoConfig;
use MercadoPago\Item;
use MercadoPago\Resources\Preference;
use MercadoPago\SDK;

class MercadoPagoService {
    /**Public Key
        TEST-32454f39-3d04-4484-96fa-5ff9402f5cd6

        Access Token
        TEST-911204885275469-050712-d23bd2267f9339817cb8dab791e08676-736474578

        viklan2b@gmail.com

        https://www.youtube.com/watch?v=HPdOyvqKAzc&ab_channel=RodrigoR%C3%ADo

        https://www.mercadopago.com.br/developers/pt/reference
        https://www.mercadopago.com.br/developers/pt/docs/checkout-pro/integrate-preferences
        https://www.mercadopago.com.br/developers/pt/docs/checkout-pro/integrate-checkout-pro/web
        https://www.mercadopago.com.br/developers/pt/live-demo/checkout-pro
        https://www.mercadopago.com.br/developers/pt/docs/checkout-pro/integration-test/test-accounts
        https://www.mercadopago.com.br/developers/panel/app/create-app
        https://www.mercadopago.com.br/developers/pt/reference/preferences/_checkout_preferences/post

    */

    /*
     * Public Key
     * TEST-2f7671c1-ec6e-4ff6-af9a-f760699020f2
     *
     * Access Token
     * TEST-6429758410265883-051009-63275dad8555974c08babdb43ab202fb-238034526
     *
     *
     */

    public function __construct()
    {
        MercadoPagoConfig::setAccessToken(env('MERCADOPAGO_ACCESS_TOKEN'));
    }

    public function criarPreferencia()
    {
        $client = new PreferenceClient();
        $preference = $client->create([
            "items"=> array(
                array(
                "title" => "Inscrição Concurso RIKASSA 2024",
                "quantity" => 1,
                "unit_price" => 10.00
                )
            ),
            "back_urls" => array(
                "success" => "http://localhost/rikassa/public/inscricao",
                "failure" => "http://localhost/rikassa/public/inscricao",
                "pending" => "http://localhost/rikassa/public/inscricao"
            ),
            "auto_return" => "approved"
        ]);

        return $preference->sandbox_init_point;

//        $client->back_urls = array(
//            "success" => "https://www.seu-site/success",
//            "failure" => "http://www.seu-site/failure",
//            "pending" => "http://www.seu-site/pending"
//        );
//        $client->auto_return = "approved";
    }


    public function obterPago()
    {
        //
    }

    public function webhookMercadoPago(Request $request)
    {
        Log::debug($request->input());
    }
}
